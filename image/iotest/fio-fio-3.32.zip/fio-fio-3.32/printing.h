#ifndef PRINTING_H
#define PRINTING_H

void gfio_print_results(struct gui_entry *ge);

#endif
